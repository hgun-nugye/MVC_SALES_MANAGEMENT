﻿USE DB_QLBH;
GO

---------------------------------------------------------
-- 1 Nhà cung cấp
---------------------------------------------------------
EXEC NhaCC_Insert N'AEON Vietnam', '02836208000', 'contact@aeon.com.vn', 'VN';
EXEC NhaCC_Insert N'Co.opXtra', '02839999555', 'support@coopmart.vn', 'VN';
EXEC NhaCC_Insert N'Pharmacity', '18006821', 'support@pharmacity.vn', 'VN';
EXEC NhaCC_Insert N'Boshop Vietnam', '02873007300', 'cskh@boshop.vn', 'VN';
EXEC NhaCC_Insert N'Concung.com', '18006609', 'support@concung.com', 'VN';
EXEC NhaCC_Insert N'Monkay.vn', '02871065666', 'support@monkay.vn', 'VN';
EXEC NhaCC_Insert N'Kosmebox', '02866808811', 'info@kosmebox.com', 'VN';
EXEC NhaCC_Insert N'Lixco Vietnam', '02838954130', 'contact@lixco.com.vn', 'VN';

EXEC NhaCC_Insert N'Tonymoly', '008221778899', 'info@tonymoly.com', 'KR';
EXEC NhaCC_Insert N'Banila Co', '008221080808', 'cs@banilaco.com', 'KR';
EXEC NhaCC_Insert N'Aritaum Korea', '008221787878', 'info@aritaum.com', 'KR';
EXEC NhaCC_Insert N'Holika Holika', '008222556677', 'contact@holikaholika.co.kr', 'KR';
EXEC NhaCC_Insert N'Peripera', '008223334444', 'support@peripera.com', 'KR';
EXEC NhaCC_Insert N'Clio Professional', '008221776655', 'info@cliocosmetic.com', 'KR';

EXEC NhaCC_Insert N'3CE Stylenanda', '008221112233', 'cs@stylenanda.com', 'KR';
EXEC NhaCC_Insert N'Dr.Jart+', '008221234888', 'support@drjart.com', 'KR';
EXEC NhaCC_Insert N'Sulwhasoo', '008221667788', 'info@sulwhasoo.com', 'KR';
EXEC NhaCC_Insert N'Hera Beauty', '008221556688', 'support@hera.com', 'KR';
EXEC NhaCC_Insert N'OHUI Korea', '008221334455', 'contact@ohui.co.kr', 'KR';
EXEC NhaCC_Insert N'Klavuu Korea', '008221777333', 'info@klavuu.com', 'KR';

EXEC NhaCC_Insert N'Estée Lauder Inc', '0018003158393', 'info@esteelauder.com', 'US';
EXEC NhaCC_Insert N'Clinique Labs', '0018002167172', 'contact@clinique.com', 'US';
EXEC NhaCC_Insert N'Maybelline New York', '0018009440730', 'support@maybelline.com', 'US';
EXEC NhaCC_Insert N'CoverGirl', '0018004268374', 'info@covergirl.com', 'US';
EXEC NhaCC_Insert N'Revlon Group', '0018004738566', 'contact@revlon.com', 'US';
EXEC NhaCC_Insert N'Neutrogena', '0018889842464', 'support@neutrogena.com', 'US';
EXEC NhaCC_Insert N'Olay', '0018002855170', 'info@olay.com', 'US';

EXEC NhaCC_Insert N'Morphe Cosmetics', '0018009991234', 'info@morphe.com', 'US';
EXEC NhaCC_Insert N'Nivea Germany', '004920123456', 'contact@nivea.de', 'DE';
EXEC NhaCC_Insert N'Schwarzkopf', '004921234567', 'info@schwarzkopf.com', 'DE';
EXEC NhaCC_Insert N'Weleda AG', '004971234567', 'support@weleda.de', 'DE';
EXEC NhaCC_Insert N'Dr. Hauschka', '004971456789', 'info@drhauschka.de', 'DE';
GO

---------------------------------------------------------
-- 2 Khách hàng
---------------------------------------------------------
EXEC KhachHang_Insert N'Nguyễn Thị Hoa', '0901234567', 'hoa.nguyen@example.com', N'Thành phố Hà Nội';
EXEC KhachHang_Insert N'Lê Minh Tuấn', '0912345678', 'tuan.le@example.com', N'Thành phố Hồ Chí Minh';
EXEC KhachHang_Insert N'Phạm Mai Anh', '0934567890', 'anh.pham@example.com', N'Thành phố Hà Nội';
EXEC KhachHang_Insert N'Nguyễn Thị Hoa', '0901234567', 'hoa.nguyen@example.com', N'Thành phố Hà Nội';
EXEC KhachHang_Insert N'Lê Minh Tuấn', '0912345678', 'tuan.le@example.com', N'Thành phố Hồ Chí Minh';

EXEC KhachHang_Insert N'Phạm Mai Anh', '0934567890', 'anh.pham@example.com', N'Thành phố Hà Nội';
EXEC KhachHang_Insert N'Trần Quốc Khánh', '0905566778', 'khanh.tran@example.com', N'Thành phố Đà Nẵng';
EXEC KhachHang_Insert N'Đỗ Minh Châu', '0989988776', 'chau.do@example.com', N'Tỉnh Bắc Ninh';
EXEC KhachHang_Insert N'Võ Thị Hạnh', '0977889900', 'hanh.vo@example.com', N'Tỉnh Đồng Nai';
EXEC KhachHang_Insert N'Lý Hải Nam', '0912233445', 'nam.ly@example.com', N'Thành phố Hải Phòng';
EXEC KhachHang_Insert N'Bùi Thanh Tùng', '0933445566', 'tung.bui@example.com', N'Tỉnh Bình Dương';
EXEC KhachHang_Insert N'Hoàng Thu Nga', '0966778899', 'nga.hoang@example.com', N'Tỉnh Thanh Hóa';
EXEC KhachHang_Insert N'Tô Ngọc Diệp', '0907788991', 'diep.to@example.com', N'Thành phố Cần Thơ';

EXEC KhachHang_Insert N'Nguyễn Thành Long', '0901112233', 'long.nguyen@example.com', N'Thành phố Hà Nội';
EXEC KhachHang_Insert N'Đinh Minh Đức', '0911445566', 'duc.dinh@example.com', N'Thành phố Hồ Chí Minh';
EXEC KhachHang_Insert N'Huỳnh Mỹ Kim', '0933998800', 'kim.huynh@example.com', N'Tỉnh Kiên Giang';
EXEC KhachHang_Insert N'Phan Quốc Huy', '0955667788', 'huy.phan@example.com', N'Tỉnh Khánh Hòa';
EXEC KhachHang_Insert N'Vũ Thu Hương', '0945566778', 'huong.vu@example.com', N'Tỉnh Nam Định';

EXEC KhachHang_Insert N'Nguyễn Nhật Tân', '0908991122', 'tan.nguyen@example.com', N'Tỉnh Nghệ An';
EXEC KhachHang_Insert N'Trương Mỹ Linh', '0935667788', 'linh.truong@example.com', N'Thành phố Đà Nẵng';
EXEC KhachHang_Insert N'Phạm Hoài Bảo', '0918002233', 'bao.pham@example.com', N'Tỉnh Vũng Tàu';
EXEC KhachHang_Insert N'Trịnh Phương Nhi', '0977334455', 'nhi.trinh@example.com', N'Tỉnh Lâm Đồng';
EXEC KhachHang_Insert N'Ngô Đức Mạnh', '0903224455', 'manh.ngo@example.com', N'Tỉnh Bắc Giang';

EXEC KhachHang_Insert N'Nguyễn Vy Oanh', '0988112233', 'oanh.nguyen@example.com', N'Thành phố Huế';
EXEC KhachHang_Insert N'Đặng Quang Phú', '0922334455', 'phu.dang@example.com', N'Tỉnh Hải Dương';
EXEC KhachHang_Insert N'Lâm Khánh Chi', '0912333444', 'chi.lam@example.com', N'Tỉnh Tây Ninh';
EXEC KhachHang_Insert N'Quách Gia Bình', '0907555666', 'binh.quach@example.com', N'Tỉnh Đồng Tháp';
EXEC KhachHang_Insert N'Triệu Thị Dung', '0944667788', 'dung.trieu@example.com', N'Tỉnh Thái Nguyên';

EXEC KhachHang_Insert N'Hoàng Minh Nhật', '0902345678', 'nhat.hoang@example.com', N'Thành phố Hà Nội';
EXEC KhachHang_Insert N'Phùng Thanh Hà', '0939223344', 'ha.phung@example.com', N'Tỉnh Quảng Nam';
EXEC KhachHang_Insert N'Đào Thị Xuân', '0977558899', 'xuan.dao@example.com', N'Tỉnh Bình Thuận';
EXEC KhachHang_Insert N'Nguyễn Hữu Tài', '0919776655', 'tai.nguyen@example.com', N'Tỉnh An Giang';
GO

---------------------------------------------------------
-- 3 Gian hàng
---------------------------------------------------------
EXEC GianHang_Insert N'L''Oréal Official Store', N'Gian hàng chính hãng L''Oréal', '0901000001', 'loreal@store.vn', N'123 Nguyễn Trãi, Quận 5, Thành phố Hồ Chí Minh';
EXEC GianHang_Insert N'Unilever Official Store', N'Gian hàng chính hãng Unilever', '0901000002', 'unilever@store.vn', N'45 Cộng Hòa, Quận Tân Bình, Thành phố Hồ Chí Minh';
EXEC GianHang_Insert N'Senka Japan Store', N'Mỹ phẩm Senka Nhật Bản', '0901000003', 'senka@store.jp', N'12 Lý Thái Tổ, Quận 10, Thành phố Hồ Chí Minh';
EXEC GianHang_Insert N'PNJ Jewelry Store', N'Trang sức chính hãng PNJ', '0901000004', 'pnj@store.vn', N'268A Lê Văn Sỹ, Quận 3, Thành phố Hồ Chí Minh';
EXEC GianHang_Insert N'Tiki Trading', N'Gian hàng chính thức Tiki', '0901000005', 'tiki@store.vn', N'52 Út Tịch, Quận Tân Bình, Thành phố Hồ Chí Minh';

EXEC GianHang_Insert N'Shopee Mall', N'Gian hàng Shopee Mall VN', '0901000006', 'mall@shopee.vn', N'88 Trần Quang Khải, Quận 1, Thành phố Hồ Chí Minh';
EXEC GianHang_Insert N'Bitis Official', N'Giày dép Biti’s chính hãng', '0901000007', 'bitis@store.vn', N'123 Nguyễn Thị Minh Khai, Quận 1, Thành phố Hồ Chí Minh';
EXEC GianHang_Insert N'Vascara Store', N'Túi xách và giày nữ', '0901000008', 'vascara@shop.vn', N'23 Trần Hưng Đạo, Quận 1, Thành phố Hồ Chí Minh';
EXEC GianHang_Insert N'Juno Official', N'Giày nữ Juno chính hãng', '0901000009', 'juno@store.vn', N'71 Nguyễn Đình Chiểu, Quận 3, Thành phố Hồ Chí Minh';
EXEC GianHang_Insert N'SamSung VN', N'Điện thoại Samsung chính hãng', '0901000010', 'samsung@vn.com', N'35 Trần Não, Thành phố Thủ Đức, Thành phố Hồ Chí Minh';

EXEC GianHang_Insert N'Điện Máy Xanh Official', N'Gia dụng & điện tử', '0911000001', 'dmx@store.vn', N'120 Trần Duy Hưng, Quận Cầu Giấy, Thành phố Hà Nội';
EXEC GianHang_Insert N'VinMart Official', N'Gian hàng thực phẩm & tiêu dùng', '0911000002', 'vinmart@store.vn', N'56 Giảng Võ, Quận Ba Đình, Thành phố Hà Nội';
EXEC GianHang_Insert N'Mediamart Store', N'Điện máy chính hãng', '0911000003', 'mediamart@store.vn', N'29 Tây Sơn, Quận Đống Đa, Thành phố Hà Nội';
EXEC GianHang_Insert N'MoMo Shop', N'Gian hàng MoMo', '0911000004', 'momo@shop.vn', N'47 Huỳnh Thúc Kháng, Quận Đống Đa, Thành phố Hà Nội';
EXEC GianHang_Insert N'Hasaki Official', N'Mỹ phẩm Hasaki', '0911000005', 'hasaki@store.vn', N'29 Quang Trung, Quận Hoàn Kiếm, Thành phố Hà Nội';

GO

---------------------------------------------------------
-- 4 Nhóm sản phẩm
---------------------------------------------------------
EXEC Nhom_Insert N'Mỹ phẩm dưỡng da';
EXEC Nhom_Insert N'Trang điểm';
EXEC Nhom_Insert N'Chăm sóc da mặt';
EXEC Nhom_Insert N'Làm sạch da mặt';
EXEC Nhom_Insert N'Tẩy trang';
EXEC Nhom_Insert N'Serum – Tinh chất';
EXEC Nhom_Insert N'Kem dưỡng ẩm';
EXEC Nhom_Insert N'Kem chống nắng';
EXEC Nhom_Insert N'Điều trị mụn';
EXEC Nhom_Insert N'Toner – Nước hoa hồng';

EXEC Nhom_Insert N'Mặt nạ – Mask';
EXEC Nhom_Insert N'Nước cân bằng da';
EXEC Nhom_Insert N'Tẩy tế bào chết';
EXEC Nhom_Insert N'Chăm sóc môi – Son dưỡng';
EXEC Nhom_Insert N'Trang điểm mặt';
EXEC Nhom_Insert N'Trang điểm mắt';
EXEC Nhom_Insert N'Son môi';
EXEC Nhom_Insert N'Chăm sóc tóc';
EXEC Nhom_Insert N'Chăm sóc cơ thể';
EXEC Nhom_Insert N'Nước hoa nữ';
EXEC Nhom_Insert N'Nước hoa nam';
EXEC Nhom_Insert N'Dụng cụ – Phụ kiện làm đẹp';
GO

---------------------------------------------------------
-- 5 Loại sản phẩm
---------------------------------------------------------
EXEC Loai_Insert N'Kem dưỡng da', 'NSP0000001';
EXEC Loai_Insert N'Serum', 'NSP0000001';
EXEC Loai_Insert N'Sữa rửa mặt', 'NSP0000001';
EXEC Loai_Insert N'Son môi', 'NSP0000002';
EXEC Loai_Insert N'Nước tẩy trang', 'NSP0000001';
GO

---------------------------------------------------------
-- 6 Sản phẩm
---------------------------------------------------------
EXEC SanPham_Insert N'La Roche-Posay Cicaplast Baume B5', 300000, 300000, 
    N'Kem phục hồi da, giảm kích ứng, phù hợp mọi loại da', 
    N'cicaplast_baume.jpg', N'Còn Hàng', 100, 'LSP0000001', 'NCC0000001', 'GH00000001';

EXEC SanPham_Insert N'Estée Lauder Advanced Night Repair', 2200000, 2500000, 
    N'Serum phục hồi da ban đêm, chống lão hóa nổi tiếng', 
    N'anr_serum.jpg', N'Hết Hàng', 50, 'LSP0000002', 'NCC0000004', 'GH00000002';

EXEC SanPham_Insert N'Cetaphil Gentle Skin Cleanser 125ml', 250000, 260000, 
    N'Sữa rửa mặt dịu nhẹ, dùng cho da nhạy cảm', 
    N'cetaphil_cleanser.jpg', N'Cháy Hàng', 80, 'LSP0000003', 'NCC0000001', 'GH00000001';

EXEC SanPham_Insert N'Maybelline SuperStay Matte Ink', 230000, 230000, 
    N'Son lì lâu trôi, giữ màu cả ngày', 
    N'maybelline_matteink.jpg', N'Cháy Hàng', 150, 'LSP0000004', 'NCC0000001', 'GH00000003';

EXEC SanPham_Insert N'L’Oréal Micellar Water 3-in-1', 180000, 180000, 
    N'Nước tẩy trang micellar làm sạch sâu', 
    N'loreal_micellar.jpg', N'Sắp Hết', 120, 'LSP0000005', 'NCC0000003', 'GH00000002';
GO

---------------------------------------------------------
-- 7 Đơn mua hàng
---------------------------------------------------------
EXEC DonMuaHang_Insert '2025-10-19', 'NCC0000001';
EXEC DonMuaHang_Insert '2025-10-19', 'NCC0000002';
EXEC DonMuaHang_Insert '2025-10-20', 'NCC0000001';
GO

---------------------------------------------------------
-- 8 Đơn bán hàng
---------------------------------------------------------
EXEC DonBanHang_Insert '2025-10-19', 'KH00000001';
EXEC DonBanHang_Insert '2025-10-19', 'KH00000002';
EXEC DonBanHang_Insert '2025-10-20', 'KH00000001';
GO
---------------------------------------------------------
-- 9 Chi tiết đơn mua hàng
---------------------------------------------------------
EXEC CTMH_Insert 'M2510190001', 'SP00000001', 50, 250000;
EXEC CTMH_Insert 'M2510190002', 'SP00000004', 100, 180000;
EXEC CTMH_Insert 'M2510200001', 'SP00000002', 30, 1800000;
GO

---------------------------------------------------------
-- 10 Chi tiết đơn bán hàng
---------------------------------------------------------
EXEC CTBH_Insert 'B2510190001', 'SP00000001', 3, 300000;
EXEC CTBH_Insert 'B2510190002', 'SP00000005', 2, 180000;
EXEC CTBH_Insert 'B2510200001', 'SP00000002', 1, 2000000;
GO

-- TaiKhoan cho Login

EXEC TaiKhoan_Insert 'admin', '123456';
